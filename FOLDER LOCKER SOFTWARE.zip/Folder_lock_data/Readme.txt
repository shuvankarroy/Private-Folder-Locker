The Folder Locker Is Developped by MR. SHUVANKAR ROY.
Thank You For Using Folder Locker Software. 

===========================================================================
DESCRIPTION:
 
Folder Locker is a software which creates a secure password protected folder vault at user's specified directory in which user can store his/her belongings.
The Secure Folder is perfectly encrypted using AES 128 bit encryption.
So, The User's Belongings remain completely safe and no one can tamper with the data.  
===========================================================================
===========================================================================
BUILD REQUIREMENTS:
 
MICROSOFT VISUAL BASIC 6.0
PYTHON 3.6

=========================================================================== 
===========================================================================
RUNTIME REQUIREMENTS:
 
WINDOWS 10,WINDOWS 8,WINDOWS 8.1,WINDOWS 7,WINDOWS XP
32 bit or 64 bit Operating System Supported 
 
===========================================================================
===========================================================================
INSTRUCTION:

1) Please Do Not Delete Any Content Of The Software as It May Cause Unusual Behaviour or Generate Error.
2) Please Wait For Some Time After Clicking Lock And Unlock Button To Let Folder Locker Complete It's Operation Flawlessly.
3) Name of Secure Folder by Default is Set To "SecureFolder".
4) Before Creating Any Secure Folder You Can Change Your Secure Folder Name.
5) User Can Change His Username and Password At Any Point Of Time by Providing The Correct Current Username & Password.
6) In Windows 10 or Windows 8 Environment The Program May Crashes Due To Non-availability of comdlg32.ocx. Follow Provided Instructions To Fix This Issue In �OS Fix� Folder. 
7) When Using Folder Locker In USB devices , Please Enable The Check Box Named "USB MODE" For Flawless Usage Each Time.